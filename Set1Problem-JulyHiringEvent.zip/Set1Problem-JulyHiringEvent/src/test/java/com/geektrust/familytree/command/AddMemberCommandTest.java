package com.geektrust.familytree.command;

import static org.junit.Assert.*;

public class AddMemberCommandTest {

}