package com.geektrust.familytree.model;

public class Relation {
	public enum Type {
		PARENT, SIBLING, SPOUSE, CHILDREN
	}
}
