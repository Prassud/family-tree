package com.geektrust.familytree.utils;

public interface Constants {
	String INVALID_PERSON = "PERSON_NOT_FOUND";

	String NO_REALATIONS = "NONE";

	String CHILD_ADDITION_SUCCEEDED = "CHILD_ADDITION_SUCCEEDED";

	String CHILD_ADDITION_FAILED = "CHILD_ADDITION_FAILED";
}
